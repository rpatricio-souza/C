#include <stdio.h>
#include <stdlib.h>

typedef struct ag{
    char horario[9];
    char data[9];
    char compromisso[100];
}AGENDA;

int main()
{
    AGENDA teste;
    return 0;
    system("PAUSE");
}
