#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, b, x;
    printf("Digite o valor de a: ");
    scanf("%f", &a);
    printf("Digite o valor de a: ");
    scanf("%f", &b);
    x = -b/a;
    printf("x = %.2f", x);
    return 0;
}
