void programa01();

void programa02();

void programa03();

void programa04();

void programa05();

void programa06();

void programa07();

void programa08();

void programa09();

void programa10();

void programa11();

void programa12();

void programa13();

void programa14();

void programa15();

void programa16();

int programa17();

void programa18();

void programa19();

void programa20();

void programa21();

void programa22();

int programa23(ano);

void programa24();

void programa25();

void programa26();

void programa27();

void programa28();

void programa29();

void programa30();

void programa31();

void programa32();

void programa33();

void programa34();

void programa35();

void programa36();

void programa37();

void programa38();

void programa39();

void programa40();

void programa41();
