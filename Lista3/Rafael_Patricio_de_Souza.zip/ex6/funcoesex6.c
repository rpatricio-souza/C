#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "funcoesex6.h"


