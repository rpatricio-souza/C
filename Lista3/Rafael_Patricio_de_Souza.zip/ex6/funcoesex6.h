void viagem();

void par_impar();

void n_10();

void multiplo3();
